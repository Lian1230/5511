BASIC INFO:
 Course: COMP 5511
 Section: DD
 Group: 18
 Instruction: Bipin C. Desai
 Assignment: 2
 Members:
  Longfeng LIAN       40040689    lo_lian@encs.concordia.ca
  Mohamed	RASHED      40038347    m_ashed@encs.concordia.ca
  Colin GALLACHER     40070588    cr.gallac@gmail.com

FILE STRUCTURE:
  Assignment 2-Answer  ---- mainly for theoretical part
  Q4                   ---- code and relevant files for question4
  Q5                   ---- code and relevant files for question5
  Q6                   ---- code and relevant files for question6