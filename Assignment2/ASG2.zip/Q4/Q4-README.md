Question: 
  Write a java program to count the number of elements in a singly linked list.
    a. Iteratively b. Recursively

Brief:
  self-implemented singly linked list without using any libray.

Files related:
  Q4.java                   --- the java file with all codes
  Assignment2_Q4            --- pdf version of Q4.java with OUTPUT result
